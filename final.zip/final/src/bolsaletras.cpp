#include "bolsaletras.h"
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <time.h>

using namespace std;

/* _________________________________________________________________________ */

BolsaLetras::BolsaLetras( const BolsaLetras & B ) {
	copiarBolsaLetras(B);
}

/* _________________________________________________________________________ */

BolsaLetras::BolsaLetras( const vector<char> & b ) {
	copiarBolsa(b);
}

/* _________________________________________________________________________ */

void BolsaLetras::setBolsa( const vector<char> & b ) {
	copiarBolsa(b);
}

/* _________________________________________________________________________ */

vector<char> BolsaLetras::getBolsa() { return bolsa; }

/* _________________________________________________________________________ */

vector<char> BolsaLetras::getLetrasEnJuego() { return letras_en_juego; }

/* _________________________________________________________________________ */

vector<string> BolsaLetras::posibilidades( const Diccionario & D ) {

	string palabra;
	vector<char> palabra_descompuesta;
	vector<string> palabras_posibles;
	bool continua;
	vector<char>::iterator it_palabra, it_letras;

	for( Diccionario::iterator it = Diccionario.begin();
		 it != Diccionario.end(); ++it ) {

		palabra = *it;

		if( palabra.size() <= letras_en_juego.size() ) {

			palabra_descompuesta.clear();

			for( int i = 0; i < palabra.size(); i++ )
				palabra_descompuesta.insert( palabra[i] );

			ordenarCaracteres( palabra_descompuesta );

			it_letras  = letras_en_juego.begin();
			it_palabra = palabra_descompuesta.begin();
			continua = true;

			while( it_palabra != palabra_descompuesta.end() &&
				   it_letras  != letras_en_juego.end() && continua) {

				if( (*it_palabra) == (*it_letras) ) {
					++it_letras;
					++it_palabra;
				} else if( (*it_palabra) > (*it_letras) ) {
					continua = false;
				} else {
					++it_letras;
				}
			}

			if( continua && ( it_palabra == palabra_descompuesta.end() ) )
				palabras_posibles.insert( palabra );

		}

	}

	return palabras_posibles;

}

/* _________________________________________________________________________ */

void BolsaLetras::letrasAleatorias( const int & num_letras ) {

	letras_en_juego.clear();
	srand( time(0) );

	for( int i = 0; i < num_letras; i++ ) {
		int random = rand() % bolsa.size();
		char letra = tolower( bolsa[random] );
		letras_en_juego.push_back( letra );
	}

	ordenarCaracteres( letras_en_juego );

}