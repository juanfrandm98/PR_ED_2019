/**
  *
  * @file diccionario.cpp
  * @brief Implementación del TDA Diccionario.
  *
  */

#include <iostream>
#include <string>
#include <set>
#include "diccionario.h"

using namespace std;

/* _________________________________________________________________________ */

Diccionario & Diccionario::operator= ( const Diccionario & D ) {

	if( this != &D ) {
		borrar();
		copiar(D);
	}

	return *this;

}

/* _________________________________________________________________________ */

Diccionario & Diccionario::operator+ ( const Diccionario & D ) {

	datos.insert( D.datos.begin(), D.Datos.end() );

}

/* _________________________________________________________________________ */

int Diccionario::frecuenciaLetra( const char & letra ) {

	set<string>::iterator it1;
	string::iterator it2;
	string palabra;
	int frecuencia = 0;

	for( it1 = datos.begin(); it1 != datos.end(); ++it1 ) {
		palabra = *it1;

		for( it2 = palabra.begin(); it2 != palabra.end(); ++it2 )
			if( *it2 == letra )
				frecuencia++;
	}

	return frecuencia;

}

/* _________________________________________________________________________ */

int Diccionario::getNumLetras() {

	int total = 0;

	for( it1 = datos.begin(); it1 != datos.end(); ++it1 )
		total += (*it).size();

	return total;

}

/* _________________________________________________________________________ */

iterator Diccionario::begin() {

	iterator i;

	i.it = datos.begin();
	i.final = datos.end();

	return i;

}

/* _________________________________________________________________________ */

iterator Diccionario::end() {

	iterator i;

	i.it = datos.end();
	i.final = datos.end();
	
	return i;

}