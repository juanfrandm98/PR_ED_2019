/**
  *
  * @file diccionario.h
  * @brief Fichero cabecera del TDA Diccionario
  *
  */

#ifndef __DICCIONARIO_H__
#define __DICCIONARIO_H__

#include <iostream>
#include <string>
#include <set>

using namespace std;

/**
  *
  * @brief T.D.A. Diccionario
  *
  *
  * @Author Juan Francisco Díaz Moreno
  * @date Diciembre 2019
  *
  */

class Diccionario {

private:

	set<string> datos;

	// Copia un diccionario en otro.
	void copiar( const Diccionario & D ) {
		borrar();
		datos.insert( D.datos.begin(), D.datos.end() );
	}

	// Elimina todos los elementos de un diccionario.
	void borrar() {
		datos.erase( datos.begin(), datos.end() );
	}

public:

	// -------------------- Constructores -------------------- //

	/**
	  *
	  * @brief Constructor por defecto.
	  *
	  */
	Diccionario(){}

	/**
	  *
	  * @brief Constructor de copia.
	  * @param D Diccionario que se va a copiar.
	  *
	  */
	Diccionario( const Diccionario & D ) { copiar(D); }

	/**
	  *
	  * @brief Destructor.
	  *
	  */
	~Diccionario() {}

	/**
	  *
	  * @brief Operador de asignación.
	  * @param D Diccionario a asignar.
	  * @return Diccionario asignado.
	  *
	  */
	Diccionario & operator= ( const Diccionario & D );

	/**
	  *
	  * @brief Operador de suma.
	  * @param D Diccionario a sumar.
	  * @return Suma de Diccionarios.
	  *
	  */
	Diccionario & operator+ ( const Diccinario & D );

	/**
	  *
	  * @brief Obtiene la contidad de veces que aparece una letra dada.
	  * @param letra Letra cuya frecuencia se quiere calcular.
	  * @return Ńúmero de apariciones de la letra dada.
	  *
	  */
	int frecuenciaLetra( const char & letra );

	/**
	  *
	  * @brief Obtiene el número de letras que hay en el Diccionario
	  * @return Número de letras totales.
	  *
	  */
	int getNumLetras();

	/**
	  *
	  * @brief Iterador sobre la clase Diccionario
	  *
	  */
	class iterator {

	private:

		set<string>::iterator it, final;

	public:

		iterator(){}

		bool operator== ( const iterator & i ) {
			return it = i.it;
		}

		bool operator!= ( const iterator & i ) {
			return it != i.it;
		}

		string & operator* () {
			return (*it);
		}

		iterator & operator++ () {
			if( it != final )
				++it;
		}

		friend class Diccionario;
	};

	/**
	  *
	  * @brief Construye un iterador que apunta al principio del
	  * set de datos.
	  * @return Iterador constuido.
	  *
	  */
	iterator begin();

	/**
	  *
	  * @brief Construye un iterador que apunta al final del set
	  * de datos.
	  * @return Iterador construido.
	  *
	  */
	iterator end();
};

#endif